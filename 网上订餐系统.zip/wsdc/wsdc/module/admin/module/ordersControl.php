<?php
$_GET['act']=isset($_GET['act'])?$_GET['act']:"list";
switch($_GET['act']){
	case "list":
		echo "<form style='padding:0px;margin:0px;' action='admin.php?mod=orders&act=list' method='post'>
		<span class='status'>订单管理</span>&nbsp;&nbsp;&nbsp;&nbsp;
		<select name='status' style='padding:0px;margin:0px;'>
		<option>不限</option>
		<option value='5'>已签收</option>
		<option value='4'>已发货</option>
		<option value='3'>已付款</option>
		<option value='2'>付款失败</option>
		<option value='1'>未付款</option>
		</select>
		<input type='submit' value='搜索'>  </form>";   
		$fsql="";$fpage="";  
		if(isset($_REQUEST['status'])&&$_REQUEST['status']!=='不限'){ $fsql.=" and status='{$_REQUEST['status']}'";$fpage.="&status={$_REQUEST['status']}";}
 		$countsql="select count(*) from orders where 1=1 $fsql";
		$pagesql="select * from orders where 1=1 $fsql order by id desc";
		$bottom="?mod=orders&ac=list";
		$datasql=page($countsql,$pagesql,$bottom,15);
		echo "<form name='delform' id='delform' action='?mod=orders&act=alldel' method='post' class='margin0'>
		<table style='width:98%;' align='center' border='1'>
		<tr height='30' align='center'>
		<td>订单号</td>
		<td style='width:200px;'>详情</td>
		<td>单价</td>
		<td>订单状态</td>
		<td>时间</td>
		<td>管理</td>
		</tr>";
		if($datasql){
			while($rs=fetch($datasql[1])){
				 $goodsArr=explode(",",$rs['gid']);
				 $retrunStr="";
				 $zongjia=0;
				 foreach($goodsArr as $new){
					 $tempArr=explode(":",$new);					  
					 $Goods=getone("select * from goods where id={$tempArr[0]}");
					 $retrunStr.="商品：{$Goods['title']},单价：{$Goods['price']},数量：{$tempArr[1]},总价：";
					 $retrunStr.=$Goods['price']*$tempArr[1];
					 $retrunStr.="\$<br>";
					 $zongjia+=$Goods['price']*$tempArr[1];
				 }
				 
				 echo "<tr height='20' style='background-color:#fff'>
				 <td align='center'><input   type=checkbox value='{$rs['id']}'  name='allidd[]' id='allidd'>{$rs['title']}</td>
				  <td align='left'>{$retrunStr}</td>
				  <td align='center'>{$rs['paymoney']}</td>
				  <td align='center'>";echo checkOrdersStatus($rs['status']);echo"</td>
				  <td align='center'>".date("Y-m-d H:i:s",$rs['ptime'])."</td>
				  <td align='center'>		  
				  <a href='admin.php?mod=orders&act=edit&id={$rs['id']}'>编辑</a>  &nbsp; &nbsp;
				  <a href='javascript:if(confirm(\"您确定要删除吗?\")) location=\"admin.php?mod=orders&act=alldel&id={$rs['id']}\" '>删除</a>
				  </td>
				  </tr>
				  <tr><td colspan=6>
				   付款方式：{$rs['spay']}<br>
				   配送地址：{$rs['saddress']} &nbsp; &nbsp; {$rs['sname']}[收]<br>
				   买家备注：{$rs['sbz']}<br>
				  </td>
				  </tr>";
			}
			echo "<tr><td colspan=7 align='right'>
					 <div style='width:280px;float:left'>{$datasql['pl']}{$datasql['pldelete']}</div>
					 <div  style='float:right'>{$datasql[2]}</div>
					 <div style='clear:both;'></div>
			</td></tr>";
		}
		echo "</table></form>";
	break;
	
	case "edit":
		$id=intval($_GET['id']);
		$Arr=getone("select * from orders  where id=$id ");
		echo "
		<center>
		<div style='width:450px;height:130px;margin-top:20px;' align='left'>
		<form style='width:420px;height:130px;' action='admin.php?mod=orders&act=save&id=$id' method='post'>
		<span class='myspan' style='width:80px;'>订单状态：</span><select name='status' style='padding:0px;margin:0px;'>
		<option value='5' ".contrast($Arr['status'],'5').">已签收</option>
		<option value='4' ".contrast($Arr['status'],'4').">已发货</option>
		<option value='3' ".contrast($Arr['status'],'3').">已付款</option>
		<option value='2' ".contrast($Arr['status'],'2').">付款失败</option>
		<option value='1' ".contrast($Arr['status'],'1').">未付款</option>
		</select> 
		<center><input type='submit' value='保存' class='submit'></center></form>
		</div></center>";	
	break;
	
	case "save":
		$id=intval($_GET['id']);
		$query="update orders set    status='{$_POST['status']}' where id=$id";
		if(query($query))
		echo "<script>alert('编辑成功');location='admin.php?mod=orders&act=list'</script>";
	break;
	
	case "alldel":
		$key=isset($_POST["allidd"])&&$_POST["allidd"]?$_POST["allidd"]:array(intval($_GET['id']));
		for($i=0;$i<count($key);$i++){ 
			$id=$key[$i];
			query("delete from orders where id=$id");
		}
    echo "<script>alert('删除成功');location='admin.php?mod=orders&act=list'</script>";
	break;
}
?>